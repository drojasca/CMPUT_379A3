Running Instrictions:
    - make:
        This will complie the project with -O (both server and client) and the pdf man files

    - make optimize:
        This will compile the project with -O (both server and client) and the pdf man files

    - make debug:
        This will compile the project with -g (both server and client) and the pdf man files
    
    -make clean:
        Remove all dependency, executables and object files

    I used the following links to help me with the dependencies and polling on the server side: https://stackoverflow.com/questions/297514/how-can-i-have-a-makefile-automatically-rebuild-source-files-that-include-a-modif/2501673 https://www.ibm.com/support/knowledgecenter/ssw_ibm_i_71/rzab6/poll.htm#:~:text=The%20only%20difference%20between%20these,to%20represent%20each%20descriptor%20number.&text=The%20poll()%20API%20allows,than%20an%20array%20of%20bits.

client.h, client.cpp:
    This file is responsible for containning the logic for the interaction with the server on the client side. It will send and recieve message from the server

server.h, server.cpp:
    This file is responsible for containning the logic for the interactions with clients. It will receive and send messages to the client

string_handler.h, string_handler.cpp
    Both version of these files are responsible for logging the interactions between the client and the server.


I decided to go with the method of sending one message and then closing the conneciton with the server. This was the easiest way to ensure that client where interleaved with the serevr. Because of TCP, non of the message sent
will be dropped.