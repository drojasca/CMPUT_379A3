#ifndef GLOBAL_H
#define GLOBAL_H

#include <istream>
#include <iostream>
#include <string>
#include <iostream>
#include <regex>
#include <vector>
#include <fcntl.h>
#include <unistd.h>
#include <sys/time.h>
#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/poll.h>
#include <unordered_map>
#include <ctime>
#include <chrono>

#endif