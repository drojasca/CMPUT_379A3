#ifndef TANDS_H
#define TANDS_H
void Sleep(int n);
void Trans(int n);
#endif